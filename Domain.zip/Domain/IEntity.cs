﻿namespace Engenharia.Gestao.De.Candidatos.Domain
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
