﻿namespace Engenharia.Gestao.De.Candidatos.Domain
{
    public class Curso : Entity
    {
        public string Nome { get; set; }
        public string Descricao { get; set; }
    }
}
