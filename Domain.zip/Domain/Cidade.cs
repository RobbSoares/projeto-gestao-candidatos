﻿namespace Engenharia.Gestao.De.Candidatos.Domain
{
    public class Cidade : Entity
    {
        public string Nome { get; set; }
        public Estado Estado { get; set; }
    }
}
