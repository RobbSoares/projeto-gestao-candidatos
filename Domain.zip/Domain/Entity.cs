﻿namespace Engenharia.Gestao.De.Candidatos.Domain
{
    public class Entity : IEntity
    {
        public int Id { get; set; }
    }
}
