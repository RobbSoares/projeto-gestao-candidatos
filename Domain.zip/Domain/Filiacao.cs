﻿namespace Engenharia.Gestao.De.Candidatos.Domain
{
    public class Filiacao : Entity
    {
        public string NomeMae { get; set; }
        public string? NomePai { get; set; }
    }
}
