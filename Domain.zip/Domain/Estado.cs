﻿namespace Engenharia.Gestao.De.Candidatos.Domain
{
    public class Estado : Entity
    {
        public string Nome { get; set; }
    }
}
